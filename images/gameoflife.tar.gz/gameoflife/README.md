
   ______                                  ____   __     _  ____
  / ____/____ _ ____ ___   ___     ____   / __/  / /    (_)/ __/___
 / / __ / __ `// __ `__ \ / _ \   / __ \ / /_   / /    / // /_ / _ \
/ /_/ // /_/ // / / / / //  __/  / /_/ // __/  / /___ / // __//  __/
\____/ \__,_//_/ /_/ /_/ \___/   \____//_/    /_____//_//_/   \___/


Game of Life that runs on bare metal
by Amey Narkhede Dec/03/2020

https://glitzflitz.github.io/
https://github.com/glitzflitz/gameoflife

This image is a tribute to late Mathematician John Conway
who passed away this April. He was active in finite groups,
combinatorial game theory and coding theory. He is most
notably well known for inventing cellular automation
called Game of Life.

Buildiing Instructions-
git clone https://github.com/glitzflitz/gameoflife
cd gameoflife
cargo install bootimage
cargo install cargo-xbuild
rustup component add rust-src
cargo xrun
